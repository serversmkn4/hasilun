const XLSX = require('xlsx');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');

const db = new sqlite3.Database('./mydatabase.db');

async function importUsersFromExcel(filePath) {
    const workbook = XLSX.readFile(filePath);
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const data = XLSX.utils.sheet_to_json(sheet);

    for (const user of data) {
        const hashedPassword = await bcrypt.hash(user.Password, 10);
        db.run('INSERT INTO users (username, password, profile, nama_kelas, nis, nisn, status_kelulusan) VALUES (?, ?, ?, ?, ?, ?, ?)', 
            [user.Username, hashedPassword, user.Profile, user['Nama Kelas'], user.NIS, user.NISN, user['Status Kelulusan']], function(err) {
            if (err) {
                console.log(`Error when inserting ${user.Username}: ${err.message}`);
            } else {
                console.log(`User ${user.Username} added successfully with ID ${this.lastID}`);
            }
        });
    }
    db.close();
}

importUsersFromExcel('./users.xlsx');
